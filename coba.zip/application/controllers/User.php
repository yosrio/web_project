<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index()
	{
		if (!isset($_SESSION['email'])) {
			redirect('auth');
		}
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['title'] = 'Profil';
		$data['role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('role_id')])->row_array();
		$data['counts'] = $this->db->count_all_results('surat_masuk');

		$data['counts2'] =$this->db->select('*')->from('surat_masuk')->where('status', 'menunggu')->count_all_results();

		$this->load->view('templates/dash_header', $data);
		$this->load->view('templates/dash_sidebar', $data);
		$this->load->view('templates/dash_navbar', $data);
		$this->load->view('user/index', $data);
		$this->load->view('templates/dash_footer', $data);
	}

	public function coba()
	{
		if (!isset($_SESSION['email'])) {
			redirect('auth');
		}

		$cuti_date = $this->input->post('tgl_surat');
		if (!empty($cuti_date)) {
			$curr_date = date('Y-m-d');
			$tgl = date('Y-m-d', strtotime('+8 days', strtotime($curr_date)));
			if ($cuti_date < $tgl) {
				echo "lebih,"."curr: ".$curr_date.", cuti: ".$cuti_date.", batas: ".$tgl;
			} else{
				echo "bisa". $curr_date.",".$tgl;
			}
		}

		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['title'] = 'Profil';
		$data['role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('role_id')])->row_array();
		$data['counts'] = $this->db->count_all_results('surat_masuk');

		$data['counts2'] =$this->db->select('*')->from('surat_masuk')->where('status', 'menunggu')->count_all_results();

		$this->load->view('templates/dash_header', $data);
		$this->load->view('templates/dash_sidebar', $data);
		$this->load->view('templates/dash_navbar', $data);
		$this->load->view('user/index', $data);
		$this->load->view('templates/dash_footer', $data);
	}
}